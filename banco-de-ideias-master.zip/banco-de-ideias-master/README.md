banco-de-ideias
===============

Um projeto para registrar, compartilhar e votar em ideias para projetos.
