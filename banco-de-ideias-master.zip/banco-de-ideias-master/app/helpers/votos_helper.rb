module VotosHelper
end
