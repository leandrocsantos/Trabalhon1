class Comentario < ActiveRecord::Base
  belongs_to :projeto  
end