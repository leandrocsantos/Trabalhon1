require 'test_helper'

class VotosHelperTest < ActionView::TestCase
end
